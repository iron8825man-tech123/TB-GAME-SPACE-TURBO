# TB GAME SPACE TURBO

A professional gaming utility launcher for Android with a premium red-and-black gaming phone interface.

## Features

✅ **Gaming Dashboard**
- Real-time system monitoring (RAM, CPU, Battery)
- Game launcher with automatic game detection
- Beautiful gaming-optimized UI with red/black theme

✅ **Game Turbo Mode**
- Pre-launch game optimization dashboard
- Quick controls (Do Not Disturb, Brightness, Screen rotation)
- System information monitoring
- Performance tracking

✅ **System Tools**
- RAM information display
- Battery status and temperature monitoring
- CPU usage tracking
- Storage information
- Network status monitoring

✅ **Settings**
- Dark mode (enabled by default)
- Animation toggle
- Haptic feedback toggle
- Auto-launch dashboard
- Brightness and orientation preferences

✅ **AMOLED Friendly**
- Pure black background (0,0,0) for power efficiency
- Red accent gaming theme
- No battery drain from UI

## Requirements

- Android 8.0 (API Level 26) or higher
- Target Android 14 (API Level 34)
- 4GB RAM minimum
- 50MB storage space

## Project Structure

```
TBGameSpaceTurbo/
├── app/
│   ├── src/main/
│   │   ├── java/com/tbgamespaceturboapk/app/
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── GameDashboardActivity.kt
│   │   │   │   └── SettingsActivity.kt
│   │   │   ├── data/
│   │   │   │   ├── GameInfo.kt
│   │   │   │   ├── GameManager.kt
│   │   │   │   └── SystemInfo.kt
│   │   │   └── service/
│   │   │       └── GamingOverlayService.kt
│   │   ├── res/
│   │   │   ├── values/
│   │   │   │   ├── colors.xml
│   │   │   │   ├── strings.xml
│   │   │   │   └── themes.xml
│   │   │   ├── drawable/
│   │   │   ├── mipmap-hdpi/
│   │   │   ├── mipmap-xhdpi/
│   │   │   └── mipmap-xxhdpi/
│   │   ├── AndroidManifest.xml
│   │   └── res/xml/
│   │       ├── backup_scheme.xml
│   │       └── data_extraction_rules.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

## Getting Started

### Prerequisites

1. **Android Studio** (Latest version) - [Download](https://developer.android.com/studio)
2. **JDK 17+** - Included with Android Studio
3. **Android SDK 34** - Installed via Android Studio SDK Manager

### Setup & Build

1. **Clone/Open the project**
   ```bash
   # If cloning from a repository
   git clone <repository-url>
   cd TBGameSpaceTurbo
   ```

2. **Open in Android Studio**
   - File → Open → Select the TBGameSpaceTurbo folder
   - Android Studio will automatically download dependencies

3. **Build the project**
   ```bash
   # In Android Studio Terminal:
   ./gradlew build
   
   # Or use Android Studio menu:
   Build → Make Project
   ```

4. **Run on device/emulator**
   ```bash
   ./gradlew installDebug
   
   # Or use Android Studio:
   Run → Run 'app'
   ```

## Creating Release Build for Google Play Store

### Step 1: Create Signing Key

1. In Android Studio:
   - Build → Generate Signed Bundle/APK
   - Select "Android App Bundle" for Play Store distribution
   - Click "Create new..."

2. Fill in the key store information:
   ```
   Key Store Path: /path/to/tbgame.jks
   Password: [Your strong password]
   Key Alias: tbgamespaceturboapk
   Key Password: [Same or different password]
   
   Validity (years): 25
   Certificate details:
   - First and Last Name: TB GAME SPACE TURBO
   - Organizational Unit: Development
   - Organization: Your Company
   - City/Locality: Your City
   - State/Province: Your State
   - Country Code: US (or your country)
   ```

3. **IMPORTANT**: Save this key store file securely. You'll need it for all future updates.

### Step 2: Generate Release Build

1. Select your signing key from the dialog
2. Select "Release" as build variant
3. Enable V2 (Full APK Signature) and V4 (Enabling 5.0+) signing
4. Click "Finish"

Android Studio will generate an `.aab` (Android App Bundle) file in:
```
app/release/app-release.aab
```

### Step 3: Prepare for Google Play Store

1. **Create Google Play Console Account**
   - Go to [Google Play Console](https://play.google.com/console)
   - Create a new app
   - Fill in app details

2. **Prepare Store Listing**
   - App name: **TB GAME SPACE TURBO**
   - Short description (80 chars):
     ```
     Professional gaming launcher with real-time system monitoring
     ```
   - Full description:
     ```
     TB GAME SPACE TURBO is a premium gaming utility launcher designed 
     for optimal gaming performance. Features include:
     
     ✅ Real-time system monitoring (RAM, CPU, Battery)
     ✅ Automatic game detection
     ✅ Game Turbo Mode for performance optimization
     ✅ Do Not Disturb, brightness, and orientation controls
     ✅ AMOLED-friendly dark interface with red gaming theme
     ✅ No ads, no tracking, privacy-friendly
     ✅ Optimized for all Android devices
     
     Made for Android Gaming
     ```
   - Category: **Tools** or **Games** (based on preference)

3. **Add Screenshots**
   - Create or capture 4-5 screenshots showing:
     - Main gaming dashboard
     - Game list
     - Turbo Mode dashboard
     - Settings screen

4. **Feature Graphic**
   - Size: 1024x500px
   - Shows app name and key features
   - Red and black theme

5. **Privacy Policy**
   - Create or add your privacy policy
   - Ensure it states: "This app collects no personal data"

### Step 4: Upload to Play Store

1. Go to **Internal Testing** → **Releases**
2. Click **Create new release**
3. Upload the `.aab` file
4. Fill in release notes:
   ```
   Version 1.0.0 - Initial Release
   
   Features:
   - Gaming dashboard with real-time system monitoring
   - Automatic game detection and launcher
   - Game Turbo Mode with quick controls
   - System tools and settings
   - AMOLED-friendly dark interface
   - Privacy-focused, no ads or tracking
   ```

5. Review and publish:
   - Start with **Internal Testing**
   - Test on real devices for 1-2 days
   - Move to **Closed Testing**
   - Finally, promote to **Production**

## Permissions Explained

The app requests these permissions only when needed:

```xml
<!-- System Information -->
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.BATTERY_STATS" />
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />

<!-- Game Detection -->
<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />

<!-- Screen & Display -->
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.ACCESS_NOTIFICATION_POLICY" />

<!-- Media Operations -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />

<!-- Floating Window -->
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
```

## Technology Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose
- **Design System**: Material 3
- **Architecture**: MVVM + Clean Architecture
- **Min SDK**: Android 8.0 (API 26)
- **Target SDK**: Android 14 (API 34)

## Important Notes

### What This App DOES NOT Do

❌ Does NOT require root access
❌ Does NOT overclock CPU or modify device voltage
❌ Does NOT modify system files or Android core
❌ Does NOT use hidden/unsafe APIs
❌ Does NOT collect personal data
❌ Does NOT include ads or tracking
❌ Does NOT force-stop other applications without permission

### Real Features Only

✅ Shows actual RAM usage (doesn't fake boosting)
✅ Shows real battery information
✅ Shows actual CPU usage (based on /proc/stat)
✅ Provides legitimate system controls (brightness, DND, rotation)
✅ Launches games using standard Android APIs
✅ Displays real-time system information

## Building APK Instead of AAB

If you prefer to build APK for testing:

```bash
./gradlew assembleRelease
```

APK location:
```
app/build/outputs/apk/release/app-release.apk
```

**Note**: Google Play Store requires AAB (.aab) format for new apps and updates.

## Troubleshooting

### Build Errors
- Clear gradle cache: `./gradlew clean`
- Sync project: File → Sync Now
- Check SDK versions in Android Studio

### Runtime Issues
- Ensure permissions are granted
- Test on actual device (not just emulator)
- Check logcat for detailed error messages

### Play Store Upload Issues
- Ensure minSdk is 26+
- Check that all required fields are filled
- Verify signing certificate is valid
- Test the APK/AAB locally first

## Version History

**1.0.0** (Initial Release)
- Gaming dashboard
- Game detection and launcher
- Turbo Mode with system controls
- Settings and preferences
- System monitoring

## License

This is a custom application. All rights reserved.

## Support

For issues or feature requests, please document them clearly with:
- Device model and Android version
- Steps to reproduce
- Screenshots/logs
- Expected vs actual behavior

## Privacy

This app respects user privacy:
- No data collection
- No tracking
- All processing done locally
- No network requests for personal data
- Transparent permission usage

---

**Made for Android Gaming** 🎮
