package com.tbgamespaceturboapk.app.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Debug
import android.os.Process
import android.os.StatFs
import java.io.File

data class SystemInfo(
    val totalRam: Float = 0f,
    val usedRam: Float = 0f,
    val availableRam: Float = 0f,
    val batteryLevel: Int = 0,
    val batteryTemperature: Int = 0,
    val batteryHealth: String = "Unknown",
    val isCharging: Boolean = false,
    val cpuUsage: Int = 0,
    val totalStorage: Long = 0,
    val availableStorage: Long = 0
) {
    companion object {
        fun getSystemInfo(context: Context): SystemInfo {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val runtime = Runtime.getRuntime()
            
            // RAM Information
            val memInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memInfo)
            
            val totalMem = runtime.totalMemory() / (1024 * 1024)
            val freeMem = runtime.freeMemory() / (1024 * 1024)
            val usedMem = totalMem - freeMem
            val totalRamGb = memInfo.totalMem / (1024 * 1024 * 1024).toFloat()
            val availableRamGb = memInfo.availMem / (1024 * 1024 * 1024).toFloat()
            val usedRamGb = totalRamGb - availableRamGb
            
            // Battery Information
            val batteryIntentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, batteryIntentFilter)
            
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 0
            val temperature = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val health = when (batteryStatus?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
                else -> "Unknown"
            }
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: 0
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || 
                            status == BatteryManager.BATTERY_STATUS_FULL
            
            // Storage Information
            try {
                val stat = StatFs("/data")
                val blockSize = stat.blockSizeLong
                val totalStorage = stat.blockCountLong * blockSize
                val availableStorage = stat.availableBlocksLong * blockSize
                
                return SystemInfo(
                    totalRam = String.format("%.1f", totalRamGb).toFloat(),
                    usedRam = String.format("%.1f", usedRamGb).toFloat(),
                    availableRam = String.format("%.1f", availableRamGb).toFloat(),
                    batteryLevel = level,
                    batteryTemperature = temperature,
                    batteryHealth = health,
                    isCharging = isCharging,
                    cpuUsage = getCPUUsage(),
                    totalStorage = totalStorage,
                    availableStorage = availableStorage
                )
            } catch (e: Exception) {
                return SystemInfo(
                    totalRam = String.format("%.1f", totalRamGb).toFloat(),
                    usedRam = String.format("%.1f", usedRamGb).toFloat(),
                    availableRam = String.format("%.1f", availableRamGb).toFloat(),
                    batteryLevel = level,
                    batteryTemperature = temperature,
                    batteryHealth = health,
                    isCharging = isCharging,
                    cpuUsage = getCPUUsage()
                )
            }
        }
        
        private fun getCPUUsage(): Int {
            return try {
                val reader = java.io.BufferedReader(java.io.FileReader("/proc/stat"))
                val load = reader.readLine()
                reader.close()
                
                val toks = load.split(" +".toRegex())
                val work = (toks[1].toLong() + toks[2].toLong() + toks[3].toLong())
                val total = (work + toks[4].toLong())
                
                ((work * 100L) / total).toInt().coerceIn(0, 100)
            } catch (e: Exception) {
                0
            }
        }
    }
}
