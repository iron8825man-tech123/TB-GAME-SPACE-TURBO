package com.tbgamespaceturboapk.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.BatteryManager
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tbgamespaceturboapk.app.R
import com.tbgamespaceturboapk.app.data.SystemInfo
import kotlinx.coroutines.delay

class GamingOverlayService : Service() {
    
    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null
    private var isVisible = false
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_OVERLAY -> showOverlay()
            ACTION_HIDE_OVERLAY -> hideOverlay()
        }
        return START_STICKY
    }
    
    private fun showOverlay() {
        if (isVisible) return
        
        overlayView = ComposeView(this).apply {
            setContent {
                GamingOverlayPanel(
                    onDismiss = { hideOverlay() }
                )
            }
        }
        
        val params = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            gravity = Gravity.TOP or Gravity.RIGHT
            width = 300
            height = 200
            x = 0
            y = 100
        }
        
        try {
            windowManager.addView(overlayView, params)
            isVisible = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun hideOverlay() {
        if (!isVisible || overlayView == null) return
        
        try {
            windowManager.removeView(overlayView)
            overlayView = null
            isVisible = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
    }
    
    companion object {
        const val ACTION_SHOW_OVERLAY = "com.tbgamespaceturboapk.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.tbgamespaceturboapk.HIDE_OVERLAY"
        
        fun startOverlay(context: Context) {
            val intent = Intent(context, GamingOverlayService::class.java)
            intent.action = ACTION_SHOW_OVERLAY
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                @Suppress("DEPRECATION")
                context.startService(intent)
            }
        }
        
        fun stopOverlay(context: Context) {
            val intent = Intent(context, GamingOverlayService::class.java)
            intent.action = ACTION_HIDE_OVERLAY
            context.startService(intent)
        }
    }
}

@Composable
fun GamingOverlayPanel(onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var systemInfo by remember { mutableStateOf(SystemInfo()) }
    
    LaunchedEffect(Unit) {
        while (true) {
            systemInfo = SystemInfo.getSystemInfo(context)
            delay(2000)
        }
    }
    
    Box(
        modifier = Modifier
            .width(280.dp)
            .background(
                color = colorResource(R.color.panel_bg),
                shape = RoundedCornerShape(12.dp)
            )
            .border(2.dp, colorResource(R.color.panel_border), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Title
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "TURBO",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = colorResource(R.color.text_red_accent)
                )
            }
            
            // System Info
            OverlayInfoItem("RAM", "${systemInfo.usedRam}GB / ${systemInfo.totalRam}GB")
            OverlayInfoItem("Battery", "${systemInfo.batteryLevel}%")
            OverlayInfoItem("CPU", "${systemInfo.cpuUsage}%")
            OverlayInfoItem("Temp", "${systemInfo.batteryTemperature}°C")
        }
    }
}

@Composable
fun OverlayInfoItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = colorResource(R.color.text_secondary)
        )
        Text(
            text = value,
            fontSize = 10.sp,
            color = colorResource(R.color.text_primary),
            fontWeight = FontWeight.Bold
        )
    }
}
