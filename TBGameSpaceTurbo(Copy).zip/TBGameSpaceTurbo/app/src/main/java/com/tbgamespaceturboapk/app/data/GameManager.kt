package com.tbgamespaceturboapk.app.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

object GameManager {
    
    // Common game package name patterns
    private val gameKeywords = listOf(
        "game", "games", "puzzle", "racing", "action", "adventure",
        "strategy", "rpg", "shooter", "battle", "multiplayer", "offline"
    )
    
    private val gamePackagePatterns = listOf(
        "com.square",
        "com.ea.",
        "com.supercell",
        "com.king",
        "com.mojang",
        "com.activision",
        "com.playrix",
        "com.outfit7",
        "com.gameloft",
        "com.netflix",
        "com.zynga"
    )
    
    fun getInstalledGames(context: Context): List<GameInfo> {
        val gameList = mutableListOf<GameInfo>()
        val pm = context.packageManager
        
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(PackageManager.GET_META_DATA)
        }
        
        for (packageInfo in packages) {
            try {
                val appInfo = packageInfo.applicationInfo
                
                // Skip system apps
                if ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0) {
                    continue
                }
                
                val packageName = packageInfo.packageName
                val appName = pm.getApplicationLabel(appInfo).toString()
                
                // Check if it's likely a game
                if (isLikelyGame(packageName, appName)) {
                    val icon = try {
                        pm.getApplicationIcon(packageName)
                    } catch (e: Exception) {
                        null
                    }
                    
                    gameList.add(
                        GameInfo(
                            packageName = packageName,
                            name = appName,
                            icon = icon,
                            version = packageInfo.versionName ?: "1.0"
                        )
                    )
                }
            } catch (e: Exception) {
                // Skip problematic packages
                continue
            }
        }
        
        return gameList.sortedBy { it.name }
    }
    
    private fun isLikelyGame(packageName: String, appName: String): Boolean {
        val lowerPackage = packageName.lowercase()
        val lowerName = appName.lowercase()
        
        // Check against known game publishers
        if (gamePackagePatterns.any { lowerPackage.startsWith(it) }) {
            return true
        }
        
        // Check keywords in package name or app name
        val keywordMatch = gameKeywords.any { keyword ->
            lowerPackage.contains(keyword) || lowerName.contains(keyword)
        }
        
        // Additional check for common gaming apps
        val commonGames = listOf(
            "playstore", "youtube", "netflix", "twitch", "discord",
            "steam", "epic", "genshin", "pubg", "fortnite"
        )
        
        return keywordMatch || commonGames.any { lowerPackage.contains(it) || lowerName.contains(it) }
    }
    
    fun launchGame(context: Context, packageName: String): Boolean {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}
