package com.tbgamespaceturboapk.app.ui

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tbgamespaceturboapk.app.R
import com.tbgamespaceturboapk.app.data.GameManager
import com.tbgamespaceturboapk.app.data.SystemInfo
import kotlinx.coroutines.delay

class GameDashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gameName = intent.getStringExtra("game_name") ?: "Game"
        val gamePackage = intent.getStringExtra("game_package") ?: ""
        
        setContent {
            GameTurboDashboard(gameName, gamePackage)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameTurboDashboard(gameName: String, gamePackage: String) {
    val context = LocalContext.current
    var systemInfo by remember { mutableStateOf(SystemInfo()) }
    var turboEnabled by remember { mutableStateOf(false) }
    var dndEnabled by remember { mutableStateOf(false) }
    var brightness by remember { mutableStateOf(50) }
    
    LaunchedEffect(Unit) {
        while (true) {
            systemInfo = SystemInfo.getSystemInfo(context)
            delay(1000)
        }
    }
    
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colorResource(R.color.bg_primary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Top Bar
            TopAppBar(
                title = { Text(gameName) },
                navigationIcon = {
                    IconButton(onClick = {
                        (context as? ComponentActivity)?.finish()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = colorResource(R.color.text_primary))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(R.color.bg_surface)
                )
            )
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Game Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = colorResource(R.color.bg_surface),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                        )
                        .border(1.dp, colorResource(R.color.card_border), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🎮",
                            fontSize = 48.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = gameName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colorResource(R.color.text_primary)
                        )
                    }
                }
                
                // System Info
                SystemInfoSection(systemInfo)
                
                // Quick Controls
                QuickControlsSection(
                    turboEnabled = turboEnabled,
                    dndEnabled = dndEnabled,
                    brightness = brightness,
                    onTurboToggle = { turboEnabled = !turboEnabled },
                    onDndToggle = { 
                        dndEnabled = !dndEnabled
                        setDoNotDisturb(context, dndEnabled)
                    },
                    onBrightnessChange = {
                        brightness = it
                        setBrightness(context, it)
                    }
                )
                
                // Start Game Button
                Button(
                    onClick = {
                        GameManager.launchGame(context, gamePackage)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colorResource(R.color.button_red)
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                ) {
                    Text(
                        stringResource(R.string.btn_start_game),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun SystemInfoSection(systemInfo: SystemInfo) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = colorResource(R.color.bg_surface),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            .border(1.dp, colorResource(R.color.card_border), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Text(
            text = "SYSTEM STATUS",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colorResource(R.color.text_red_accent),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        
        InfoRow("RAM", "${systemInfo.usedRam}/${systemInfo.totalRam} GB")
        Spacer(modifier = Modifier.height(8.dp))
        InfoRow("Battery", "${systemInfo.batteryLevel}%")
        Spacer(modifier = Modifier.height(8.dp))
        InfoRow("Temperature", "${systemInfo.batteryTemperature}°C")
        Spacer(modifier = Modifier.height(8.dp))
        InfoRow("CPU Usage", "${systemInfo.cpuUsage}%")
        Spacer(modifier = Modifier.height(8.dp))
        InfoRow("Status", if (systemInfo.isCharging) "Charging" else "Discharging")
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = colorResource(R.color.text_secondary),
            fontSize = 14.sp
        )
        Text(
            text = value,
            color = colorResource(R.color.text_primary),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun QuickControlsSection(
    turboEnabled: Boolean,
    dndEnabled: Boolean,
    brightness: Int,
    onTurboToggle: () -> Unit,
    onDndToggle: () -> Unit,
    onBrightnessChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = colorResource(R.color.bg_surface),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            .border(1.dp, colorResource(R.color.card_border), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Text(
            text = "QUICK CONTROLS",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colorResource(R.color.text_red_accent),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        
        // Turbo Mode Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Turbo Mode", color = colorResource(R.color.text_primary))
            Switch(
                checked = turboEnabled,
                onCheckedChange = { onTurboToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = colorResource(R.color.button_red),
                    checkedTrackColor = colorResource(R.color.red_transparent_30)
                )
            )
        }
        
        Divider(color = colorResource(R.color.divider), thickness = 1.dp)
        
        // DND Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Do Not Disturb", color = colorResource(R.color.text_primary))
            Switch(
                checked = dndEnabled,
                onCheckedChange = { onDndToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = colorResource(R.color.button_red),
                    checkedTrackColor = colorResource(R.color.red_transparent_30)
                )
            )
        }
        
        Divider(color = colorResource(R.color.divider), thickness = 1.dp)
        
        // Brightness Control
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Brightness", color = colorResource(R.color.text_primary))
                Text("$brightness%", color = colorResource(R.color.text_red_accent), fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Slider(
                value = brightness.toFloat(),
                onValueChange = { onBrightnessChange(it.toInt()) },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = colorResource(R.color.button_red),
                    activeTrackColor = colorResource(R.color.button_red)
                )
            )
        }
    }
}

private fun setDoNotDisturb(context: Context, enable: Boolean) {
    try {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (enable) {
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            } else {
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        }
    } catch (e: Exception) {
        // Permission denied or not available
    }
}

private fun setBrightness(context: Context, brightness: Int) {
    try {
        val contentResolver = context.contentResolver
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, brightness)
    } catch (e: Exception) {
        // Permission denied or not available
    }
}
