package com.tbgamespaceturboapk.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tbgamespaceturboapk.app.R

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SettingsScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    var darkMode by remember { mutableStateOf(true) }
    var animationsEnabled by remember { mutableStateOf(true) }
    var hapticEnabled by remember { mutableStateOf(true) }
    var autoLaunchDashboard by remember { mutableStateOf(true) }
    var selectedBrightness by remember { mutableStateOf("Auto") }
    var selectedOrientation by remember { mutableStateOf("Portrait") }
    
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colorResource(R.color.bg_primary)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar
            TopAppBar(
                title = { Text(stringResource(R.string.title_settings)) },
                navigationIcon = {
                    IconButton(onClick = {
                        (context as? ComponentActivity)?.finish()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = colorResource(R.color.text_primary))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(R.color.bg_surface)
                )
            )
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Appearance Section
                SettingsSection(title = stringResource(R.string.settings_appearance)) {
                    SettingItem(
                        label = stringResource(R.string.setting_dark_mode),
                        checked = darkMode,
                        onToggle = { darkMode = !darkMode }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingItem(
                        label = stringResource(R.string.setting_animations),
                        checked = animationsEnabled,
                        onToggle = { animationsEnabled = !animationsEnabled }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingItem(
                        label = stringResource(R.string.setting_haptic),
                        checked = hapticEnabled,
                        onToggle = { hapticEnabled = !hapticEnabled }
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Gaming Section
                SettingsSection(title = stringResource(R.string.settings_gaming)) {
                    SettingItem(
                        label = stringResource(R.string.setting_auto_launch),
                        checked = autoLaunchDashboard,
                        onToggle = { autoLaunchDashboard = !autoLaunchDashboard }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    DropdownSetting(
                        label = stringResource(R.string.setting_brightness_pref),
                        currentValue = selectedBrightness,
                        options = listOf("Auto", "Manual", "Adaptive"),
                        onValueChange = { selectedBrightness = it }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    DropdownSetting(
                        label = stringResource(R.string.setting_orientation_pref),
                        currentValue = selectedOrientation,
                        options = listOf("Portrait", "Landscape", "Auto"),
                        onValueChange = { selectedOrientation = it }
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // About Section
                SettingsSection(title = stringResource(R.string.settings_about)) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = colorResource(R.color.bg_surface),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .border(1.dp, colorResource(R.color.divider), RoundedCornerShape(8.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.about_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colorResource(R.color.text_primary)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.about_version),
                            fontSize = 14.sp,
                            color = colorResource(R.color.text_secondary)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.about_description),
                            fontSize = 14.sp,
                            color = colorResource(R.color.text_red_accent),
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = stringResource(R.string.about_copyright),
                            fontSize = 12.sp,
                            color = colorResource(R.color.text_tertiary)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colorResource(R.color.text_red_accent),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = colorResource(R.color.bg_surface),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(1.dp, colorResource(R.color.card_border), RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            content()
        }
    }
}

@Composable
fun SettingItem(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = colorResource(R.color.text_primary),
            fontSize = 14.sp
        )
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = colorResource(R.color.button_red),
                checkedTrackColor = colorResource(R.color.red_transparent_30)
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownSetting(
    label: String,
    currentValue: String,
    options: List<String>,
    onValueChange: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = colorResource(R.color.bg_secondary),
                    shape = RoundedCornerShape(8.dp)
                )
                .border(1.dp, colorResource(R.color.divider), RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = label,
                    color = colorResource(R.color.text_secondary),
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = currentValue,
                    color = colorResource(R.color.text_primary),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Box {
                IconButton(onClick = { expanded = !expanded }) {
                    Text("▼", color = colorResource(R.color.text_red_accent))
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier.background(colorResource(R.color.bg_surface))
                ) {
                    options.forEach { option ->
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    option,
                                    color = colorResource(R.color.text_primary)
                                ) 
                            },
                            onClick = {
                                onValueChange(option)
                                expanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}
