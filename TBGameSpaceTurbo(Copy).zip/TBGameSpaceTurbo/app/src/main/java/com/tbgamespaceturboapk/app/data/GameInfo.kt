package com.tbgamespaceturboapk.app.data

import android.graphics.drawable.Drawable

data class GameInfo(
    val packageName: String,
    val name: String,
    val icon: Drawable? = null,
    val version: String = "Unknown",
    val size: Long = 0,
    val lastLaunched: Long = 0
)
