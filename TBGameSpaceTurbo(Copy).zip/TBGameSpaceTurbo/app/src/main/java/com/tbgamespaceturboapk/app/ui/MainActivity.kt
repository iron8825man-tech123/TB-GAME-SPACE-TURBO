package com.tbgamespaceturboapk.app.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tbgamespaceturboapk.app.R
import com.tbgamespaceturboapk.app.data.GameInfo
import com.tbgamespaceturboapk.app.data.GameManager
import com.tbgamespaceturboapk.app.data.SystemInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainGameDashboard()
        }
    }
}

@Composable
fun MainGameDashboard() {
    val context = LocalContext.current
    var games by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    var systemInfo by remember { mutableStateOf(SystemInfo()) }
    var turboModeEnabled by remember { mutableStateOf(false) }
    var showAddGameDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            systemInfo = SystemInfo.getSystemInfo(context)
            games = GameManager.getInstalledGames(context)
            delay(2000)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colorResource(R.color.bg_primary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Header
            GamingHeader()

            Spacer(modifier = Modifier.height(24.dp))

            // System Info Bar
            SystemInfoBar(systemInfo)

            Spacer(modifier = Modifier.height(24.dp))

            // Turbo Mode Toggle
            TurboModeButton(
                turboModeEnabled,
                onToggle = { turboModeEnabled = !turboModeEnabled }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Games Section
            Text(
                text = "GAMES",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = colorResource(R.color.text_red_accent),
                modifier = Modifier.padding(vertical = 8.dp)
            )

            if (games.isEmpty()) {
                EmptyGamesPlaceholder {
                    showAddGameDialog = true
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(games) { game ->
                        GameCard(game) {
                            val intent = Intent(context, GameDashboardActivity::class.java)
                            intent.putExtra("game_package", game.packageName)
                            intent.putExtra("game_name", game.name)
                            context.startActivity(intent)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Add Game Button
            Button(
                onClick = { showAddGameDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colorResource(R.color.button_red)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.btn_add_game), fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Settings Button
            Button(
                onClick = {
                    context.startActivity(Intent(context, SettingsActivity::class.java))
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colorResource(R.color.bg_surface)
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.material3.ButtonDefaults.outlinedButtonBorder
            ) {
                Icon(Icons.Filled.Settings, contentDescription = null, tint = colorResource(R.color.text_red_accent))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.btn_settings), color = colorResource(R.color.text_red_accent))
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showAddGameDialog) {
        AddGameDialog(
            onDismiss = { showAddGameDialog = false },
            onGameAdded = {
                games = GameManager.getInstalledGames(context)
            }
        )
    }
}

@Composable
fun GamingHeader() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "TB GAME SPACE TURBO",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = colorResource(R.color.text_primary),
            modifier = Modifier.padding(vertical = 8.dp)
        )
        Text(
            text = "GAMING DASHBOARD",
            fontSize = 14.sp,
            color = colorResource(R.color.text_red_accent),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SystemInfoBar(systemInfo: SystemInfo) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = colorResource(R.color.bg_surface),
                shape = RoundedCornerShape(12.dp)
            )
            .border(1.dp, colorResource(R.color.card_border), RoundedCornerShape(12.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        SystemInfoItem(
            label = "RAM",
            value = "${systemInfo.usedRam}/${systemInfo.totalRam}GB"
        )
        SystemInfoItem(
            label = "BATTERY",
            value = "${systemInfo.batteryLevel}%"
        )
        SystemInfoItem(
            label = "CPU",
            value = "${systemInfo.cpuUsage}%"
        )
    }
}

@Composable
fun RowScope.SystemInfoItem(label: String, value: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.weight(1f)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = colorResource(R.color.text_red_accent),
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 14.sp,
            color = colorResource(R.color.text_primary),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TurboModeButton(isEnabled: Boolean, onToggle: () -> Unit) {
    Button(
        onClick = onToggle,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isEnabled) colorResource(R.color.button_red) else colorResource(R.color.bg_surface)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = if (isEnabled) "🔥 TURBO MODE ON" else "⚙️ TURBO MODE OFF",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = if (isEnabled) Color.White else colorResource(R.color.text_red_accent)
        )
    }
}

@Composable
fun GameCard(game: GameInfo, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .shadow(8.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = colorResource(R.color.bg_surface)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(colorResource(R.color.bg_secondary), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🎮",
                    fontSize = 32.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = game.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = colorResource(R.color.text_primary),
                maxLines = 2
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(colorResource(R.color.red_transparent_10))
                .border(1.dp, colorResource(R.color.card_border), RoundedCornerShape(12.dp))
        )
    }
}

@Composable
fun EmptyGamesPlaceholder(onAddGame: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(colorResource(R.color.bg_surface), RoundedCornerShape(12.dp))
            .border(2.dp, colorResource(R.color.card_border), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "📱",
                fontSize = 48.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.msg_no_games),
                color = colorResource(R.color.text_secondary),
                fontSize = 14.sp,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Composable
fun AddGameDialog(onDismiss: () -> Unit, onGameAdded: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select a Game to Add") },
        text = { Text("Choose from your installed games") },
        confirmButton = { Button(onClick = onDismiss) { Text("Close") } },
        containerColor = colorResource(R.color.bg_surface),
        titleContentColor = colorResource(R.color.text_primary),
        textContentColor = colorResource(R.color.text_secondary)
    )
}
